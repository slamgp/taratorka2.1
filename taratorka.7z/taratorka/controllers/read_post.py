# coding: utf8
# попробовать что-либо вида
def index(): return dict(message="hello from read_post.py")