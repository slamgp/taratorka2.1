from gluon.storage import Storage
settings = Storage()

settings.migrate = True
settings.title = 'TARATORKA'
settings.subtitle = ''
settings.author = 'Panchenko'
settings.author_email = 'slamgp1987@gmail.com'
settings.keywords = 'chat \xd1\x87\xd0\xb0\xd1\x82  \xd0\xbf\xd0\xbe\xd0\xbe\xd0\xb1\xd1\x89\xd0\xb0\xd1\x82\xd1\x8c\xd1\x81\xd1\x8f  \xd0\xbf\xd0\xbe\xd0\xb3\xd0\xbe\xd0\xb2\xd0\xbe\xd1\x80\xd0\xb8\xd1\x82\xd1\x8c  talk'
settings.description = 'Taratorka - Web Chat where you can discuss any topic. Meet interesting people, make new friends, and just relax talking to your favorite topics !!!'
settings.layout_theme = 'Default'
settings.database_uri = 'sqlite://storage.sqlite'
settings.security_key = '46caa0ff-153b-465e-93f1-7b05e3b19004'
settings.email_server = 'localhost'
settings.email_sender = 'slamgp@yandex.ru'
settings.email_login = 'slamgp'
settings.login_method = 'local'
settings.login_config = ''
settings.plugins = []
